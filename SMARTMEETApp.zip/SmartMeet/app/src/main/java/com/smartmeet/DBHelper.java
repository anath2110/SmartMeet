package com.smartmeet;

/**
 * Created by user on 20-Apr-17.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "SmartMeet.db";
    public static final String CONTACTS_TABLE_NAME = "contacts";
    public static final String EVENTS_TABLE_NAME = "events";
    public static final String CONTACTS_COLUMN_ID = "id";
    public static final String CONTACTS_COLUMN_NAME = "name";
    public static final String CONTACTS_COLUMN_CONTACT = "contact";
    public static final String CONTACTS_CREATOR_NAME = "creatorname";
    public static final String CONTACTS_CREATOR_CONTACT = "creatorcontact";

    public static final String EVENT_NAME_COLUMN = "eventname";
    public static final String EVENT_DURATION_COLUMN = "duration";
    public static final String EVENT_DATE_COLUMN = "eventdate";
    public static final String EVENT_TIME_COLUMN = "eventtime";

    public static final String Query1 = "create table contacts " +
            "(id integer primary key AUTOINCREMENT , creatorname text,creatorcontact text,  name text,contact text)";

    public static final String Query2 = "create table events " +
            "(id integer primary key AUTOINCREMENT , creatorname text ,eventname text,duration text,  eventdate text,eventtime text)";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(Query1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean insertContact(String creatorName, String creatorConact, String name, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CONTACTS_CREATOR_NAME, creatorName);
        contentValues.put(CONTACTS_CREATOR_CONTACT, creatorConact);
        contentValues.put(CONTACTS_COLUMN_NAME, name);
        contentValues.put(CONTACTS_COLUMN_CONTACT, phone);
        db.insert(CONTACTS_TABLE_NAME, null, contentValues);
        return true;
    }

    public ArrayList<UserData> getData() {
        ArrayList<UserData> array_list = new ArrayList<UserData>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            String crtrName = res.getString(res.getColumnIndex(CONTACTS_CREATOR_NAME));
            String crtrContact = res.getString(res.getColumnIndex(CONTACTS_CREATOR_CONTACT));
            String participantName = res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME));
            String participantContact = res.getString(res.getColumnIndex(CONTACTS_COLUMN_CONTACT));

            array_list.add(new UserData(crtrName, crtrContact, participantName, participantContact));
            res.moveToNext();
        }
        return array_list;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }


    public ArrayList<String> getAllCotacts() {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from contacts", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }

    public boolean insertEvent(String creatorName, String event_name, String duration, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(CONTACTS_CREATOR_NAME, creatorName);
        contentValues.put(EVENT_NAME_COLUMN, event_name);
        contentValues.put(EVENT_DURATION_COLUMN, duration);
        contentValues.put(EVENT_DATE_COLUMN, date);
        contentValues.put(EVENT_TIME_COLUMN, time);

        db.insert(EVENTS_TABLE_NAME, null, contentValues);
        return true;

    }

    public class UserData {
        private String creatorname, creatorContact, participantName, participantContact;

        public UserData(String creatorname, String creatorContact, String participantName, String participantContact) {
            this.creatorname = creatorname;
            this.creatorContact = creatorContact;
            this.participantName = participantName;
            this.participantContact = participantContact;
        }

        public String getCreatorname() {
            return creatorname;
        }

        public void setCreatorname(String creatorname) {
            this.creatorname = creatorname;
        }

        public String getCreatorContact() {
            return creatorContact;
        }

        public void setCreatorContact(String creatorContact) {
            this.creatorContact = creatorContact;
        }

        public String getParticipantName() {
            return participantName;
        }

        public void setParticipantName(String participantName) {
            this.participantName = participantName;
        }

        public String getParticipantContact() {
            return participantContact;
        }

        public void setParticipantContact(String participantContact) {
            this.participantContact = participantContact;
        }
    }
}