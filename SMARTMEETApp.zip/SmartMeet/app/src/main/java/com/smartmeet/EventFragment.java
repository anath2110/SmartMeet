package com.smartmeet;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;


public class EventFragment extends Fragment {


    private static final int DATE_DIALOG_ID = 1;
    private static EditText datepickEditText, timepickerEditText;
    public static boolean isDate = true;
    private EditText eventNameEditText, durationEditText;
    private Button addEventButton, sendButton;
    private DBHelper dbHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_event, container, false);

        dbHelper = new DBHelper(getActivity());

        eventNameEditText = (EditText) view.findViewById(R.id.eventname_et);
        durationEditText = (EditText) view.findViewById(R.id.duration_et);


        datepickEditText = (EditText) view.findViewById(R.id.datepicker_et);
        datepickEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* new DatePickerDialog(getActivity(), datePickerListener,
                        year, month, day);*/
                isDate = true;
                DialogFragment newFragment = new SelectDateFragment();
                newFragment.show(getFragmentManager(), "DatePicker");

            }
        });

        timepickerEditText = (EditText) view.findViewById(R.id.timepicker_et);
        timepickerEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* new DatePickerDialog(getActivity(), datePickerListener,
                        year, month, day);*/
                isDate = false;
                DialogFragment newFragment = new SelectDateFragment();
                newFragment.show(getFragmentManager(), "TimePicker");

            }
        });

        addEventButton = (Button) view.findViewById(R.id.plus_btn);
        sendButton = (Button) view.findViewById(R.id.send_btn);
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (eventNameEditText.getText() == null)
                    Toast.makeText(getActivity(), "Please enter event name", Toast.LENGTH_SHORT).show();
                else if (durationEditText.getText() == null)
                    Toast.makeText(getActivity(), "Please enter duration of the event", Toast.LENGTH_SHORT).show();
                else {
                    String event_name = eventNameEditText.getText().toString().trim();
                    String duration = durationEditText.getText().toString().trim();


                   /* if (dbHelper.insertEvent(creatorname ,event_name, duration, "04/2/2017", "5:00am")) {
                        Toast.makeText(getActivity(), "Participant added successfully.", Toast.LENGTH_SHORT).show();
                    }*/
                }
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        return view;
    }

    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                // set date picker as current date
                return new DatePickerDialog(getActivity(), datePickerListener,
                        year, month, day);
        }
        return null;
    }

    private int year, month, day;
    private DatePickerDialog.OnDateSetListener datePickerListener
            = new DatePickerDialog.OnDateSetListener() {


        // when dialog box is closed, below method will be called.
        @Override
        public void onDateSet(DatePicker view, int selectedYear,
                              int selectedMonth, int selectedDay) {
            year = selectedYear;
            month = selectedMonth;
            day = selectedDay;

            // set selected date into textview
            String selectedDate = new StringBuilder().append(month + 1)
                    .append("-").append(day).append("-").append(year)
                    .append(" ").toString();

            datepickEditText.setText(selectedDate);

        }
    };

    public static class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            int yy = calendar.get(Calendar.YEAR);
            int mm = calendar.get(Calendar.MONTH);
            int dd = calendar.get(Calendar.DAY_OF_MONTH);
            int HH = calendar.get(Calendar.HOUR);
            int min = calendar.get(Calendar.MINUTE);

            if (isDate)
                return new DatePickerDialog(getActivity(), this, yy, mm, dd);
            else
                return new TimePickerDialog(getActivity(), timePickerListener, HH, min, true);
        }

        public void onDateSet(DatePicker view, int yy, int mm, int dd) {
            populateSetDate(yy, mm + 1, dd);
        }

        public void populateSetDate(int year, int month, int day) {
            datepickEditText.setText(month + "/" + day + "/" + year);
        }



        private TimePickerDialog.OnTimeSetListener timePickerListener =
                new TimePickerDialog.OnTimeSetListener() {
                    public void onTimeSet(TimePicker view, int selectedHour,
                                          int selectedMinute) {

                        timepickerEditText.setText(selectedHour + ":" + selectedMinute);
                    }
                };
    }
}
