package com.smartmeet;

import android.app.SearchManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class GroupFragment extends Fragment {
    public static String[] countries = {"Afghanistan", "Albania", "Algeria",
            "American Samoa", "Andorra"};
    public static String[] abbreviations = {"AF", "AL", "DZ", "AS", "AD"};

    TableLayout tableLayout;
    //private TextView autoCompleteTextView;
    private ArrayAdapter<String> adapter;

    // Store contacts values in these arraylist
    public static ArrayList<String> phoneValueArr = new ArrayList<String>();
    public static ArrayList<String> nameValueArr = new ArrayList<String>();
    private SearchView searchView;

    private EditText creator_nameEditText, creator_contactEditText, searchEditText;
    private Button saveButton;
    public static String participantName, participantNumber;

    private DBHelper dbHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_group,
                container, false);

        dbHelper = new DBHelper(getActivity());

        tableLayout = (TableLayout) view.findViewById(R.id.country_table);
       // searchView = (SearchView) view.findViewById(R.id.searchView);
        creator_nameEditText = (EditText) view.findViewById(R.id.name_et);
        creator_contactEditText = (EditText) view.findViewById(R.id.contact_et);
        //autoCompleteTextView = (TextView) view.findViewById(R.id.searchAuto_et);
        searchEditText = (EditText) view.findViewById(R.id.searchAuto_et);

        saveButton = (Button) view.findViewById(R.id.plus_btn);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (creator_nameEditText.getText() == null)
                    Toast.makeText(getActivity(), "Please enter creator name", Toast.LENGTH_SHORT).show();
                else if (creator_contactEditText.getText() == null)
                    Toast.makeText(getActivity(), "Please enter creator contact", Toast.LENGTH_SHORT).show();
                else if (searchEditText.getText() == null)
                    Toast.makeText(getActivity(), "Please enter name you want to add", Toast.LENGTH_SHORT).show();
                else {
                    String name = creator_nameEditText.getText().toString().trim();
                    String contact = creator_contactEditText.getText().toString().trim();

                    String searchedName = searchEditText.getText().toString();


                    String searched_Contact;
                    if (nameValueArr.contains(searchedName)) {
                        int i = nameValueArr.indexOf(searchedName);
                        searched_Contact = phoneValueArr.get(i);

                        if (dbHelper.insertContact(name, contact, searchedName, searched_Contact)) {
                            fillParticipantTable(searchedName, searched_Contact);
                            Toast.makeText(getActivity(), "Participant added successfully.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });

        readContactData();
        //show current participants
        fillParticipantTable("", "");
        return view;
    }

    void fillParticipantTable(String participantName, String participantContact) {

        TableRow row;
        TextView t1;
        EditText t2, t3;
        Button editButton, deleteButton;
        ArrayList<String> participantNameList = new ArrayList<>();
        ArrayList<String> participantContactList = new ArrayList<>();

        if (participantName.length() != 0 || participantContact.length() != 0) {
            participantNameList.add(participantName);
            participantContactList.add(participantContact);
        }


        //get all saved participant and add to current lists
        ArrayList<DBHelper.UserData> dataArrayList = dbHelper.getData();

        for (int i = 0; i < dataArrayList.size(); i++) {
            DBHelper.UserData userData = dataArrayList.get(i);

            String prtName = userData.getParticipantName();
            String prtContact = userData.getParticipantContact();

            participantNameList.add(prtName);
            participantContactList.add(prtContact);
        }

        //Converting to dip unit
        int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                (float) 1, getResources().getDisplayMetrics());

        for (int current = 0; current < participantContactList.size(); current++) {
            row = new TableRow(getActivity());

            t1 = new TextView(getActivity());
            t1.setTextColor(getResources().getColor(R.color.colorPrimary));
            t2 = new EditText(getActivity());
            t2.setTextColor(getResources().getColor(R.color.colorAccent));
            t3 = new EditText(getActivity());
            t3.setTextColor(getResources().getColor(R.color.black));

            editButton = new Button(getActivity());
            editButton.setText("Edit");
            deleteButton = new Button(getActivity());
            deleteButton.setText("Delete");

            t1.setText(current + ".");
            t2.setText(participantNameList.get(current));
            t3.setText(participantContactList.get(current));

            t1.setTypeface(null, 1);
            t2.setTypeface(null, 1);

            t1.setTextSize(15);
            t2.setTextSize(15);

            t1.setWidth(30 * dip);
            t2.setWidth(100 * dip);
            t3.setWidth(100 * dip);

            t1.setPadding(20 * dip, 0, 0, 0);
            row.addView(t1);
            row.addView(t2);
            row.addView(t3);
            row.addView(editButton);
            row.addView(deleteButton);

            tableLayout.addView(row, new TableLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        }
    }

    private void setupSearchView() {
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
       /*  SearchableInfo searchableInfo = searchManager.getSearchableInfo(getComponentName());
        searchView.setSearchableInfo(searchableInfo);*/
    }

    public void getIntentData(Intent intent) {
        if (ContactsContract.Intents.SEARCH_SUGGESTION_CLICKED.equals(intent.getAction())) {
            //handles suggestion clicked query
            String displayName = getDisplayNameForContact(intent);
          //  searchEditText.setText(displayName);
        } else if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            // handles a search query
            String query = intent.getStringExtra(SearchManager.QUERY);
           // searchEditText.setText("should search for query: '" + query + "'...");
        }
    }

    private String getDisplayNameForContact(Intent intent) {
        Cursor phoneCursor = getActivity().getContentResolver().query(intent.getData(), null, null, null, null);
        phoneCursor.moveToFirst();
        int idDisplayName = phoneCursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
        String name = phoneCursor.getString(idDisplayName);
        phoneCursor.close();
        return name;
    }
    // Read phone contact name and phone numbers

    private void readContactData() {

        try {

            /*********** Reading Contacts Name And Number **********/

            String phoneNumber = "";
            ContentResolver cr = getActivity().getContentResolver();

            //Query to get contact name

            Cursor cur = cr
                    .query(ContactsContract.Contacts.CONTENT_URI,
                            null,
                            null,
                            null,
                            null);

            // If data data found in contacts
            if (cur.getCount() > 0) {


                int k = 0;
                String name = "";

                while (cur.moveToNext()) {

                    String id = cur
                            .getString(cur
                                    .getColumnIndex(ContactsContract.Contacts._ID));
                    name = cur
                            .getString(cur
                                    .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                    //Check contact have phone number
                    if (Integer
                            .parseInt(cur
                                    .getString(cur
                                            .getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {

                        //Create query to get phone number by contact id
                        Cursor pCur = cr
                                .query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                        null,
                                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID
                                                + " = ?",
                                        new String[]{id},
                                        null);
                        int j = 0;

                        while (pCur
                                .moveToNext()) {
                            // Sometimes get multiple data
                            if (j == 0) {
                                // Get Phone number
                                phoneNumber = "" + pCur.getString(pCur
                                        .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

                                // Add contacts names to adapter
                                adapter.add(name);

                                // Add ArrayList names to adapter
                                phoneValueArr.add(phoneNumber.toString());
                                nameValueArr.add(name.toString());

                                j++;
                                k++;
                            }
                        }  // End while loop
                        pCur.close();
                    } // End if

                }  // End while loop

            } // End Cursor value check
            cur.close();


        } catch (Exception e) {
        }


    }

}
